#include <stdio.h>
#include <string.h>

typedef enum action {
  read_text,
  write_text,
  read_binary,
  write_binary
} action_t;

/* Valid switches to main are:
 * -wt  Write text
 * -wb  Write binary
 * -rt  Read text
 * -rb  Read binary
 */

int main(int argc, char *argv[])
{
  FILE *f;
  struct {
    int i;
    int j;
  } s = { 1, 2 };
  action_t action;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <-wt|-wb|-rt|-rb>\n", argv[0]);

    return -1;
  }

  if (!strcmp(argv[1], "-wt")) {
    action = write_text;
  } else if (!strcmp(argv[1], "-wb")) {
    action = write_binary;
  } else if (!strcmp(argv[1], "-rt")) {
    action = read_text;
  } else if (!strcmp(argv[1], "-rb")) {
    action = read_binary;
  } else {
    fprintf(stderr, "Usage: %s <-wt|-wb|-rt|-rb>\n", argv[0]);

    return -1;
  }

  switch (action) {
  case write_text:
    if (!(f = fopen("text_file", "w"))) {
      fprintf(stderr, "Failed to open file for writing");

      return -1;
    }

    fprintf(f, "%d %d\n", s.i, s.j);

    fclose(f);
    break;

  case read_text:
    if (!(f = fopen("text_file", "r"))) {
      fprintf(stderr, "Failed to open file for reading");

      return -1;
    }

    s.i = s.j = 0;

    fscanf(f, "%d %d\n", &s.i, &s.j);

    printf("%d %d\n", s.i, s.j);

    fclose(f);
    break;

  case write_binary:
    if (!(f = fopen("binary_file", "w"))) {
      fprintf(stderr, "Failed to open file for writing");

      return -1;
    }

    if (fwrite(&s, sizeof (s), 1, f) != 1) {
      fprintf(stderr, "Write failed!");

      return -1;
    }

    fclose(f);

    break;

  case read_binary:
    if (!(f = fopen("binary_file", "r"))) {
      fprintf(stderr, "Failed to open file for reading");

      return -1;
    }

    s.i = s.j = 0;
    if (fread(&s, sizeof (s), 1, f) != 1) {
      fprintf(stderr, "Read failed!");

      return -1;
    }

    printf("%d %d\n", s.i, s.j);

    fclose(f);

    break;
  }

  return 0;
}
