#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
  cout << "Hello World!" << endl;

  return 0;
}

